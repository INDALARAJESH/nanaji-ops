import json

def debug(event):
    """ debug event """
    print(json.dumps(event, indent=4))

def lambda_handler(event, context):
    """ AWS Lambda Handler """
    debug(event)
